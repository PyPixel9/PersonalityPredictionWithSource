
import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
import joblib

# Load trained model and other utilities
model = joblib.load("logreg_model.pkl")
vectorizer = joblib.load("vectorizer.pkl")
label_encoder = joblib.load("label_encoder.pkl")

def predict_personality(user_input):
    transformed_input = vectorizer.transform([user_input])
    prediction = model.predict(transformed_input)
    decoded_prediction = label_encoder.inverse_transform([prediction])[0]
    return decoded_prediction

st.title('MBTI Personality Predictor')

user_input = st.text_area("Enter a text about yourself:", value='', height=200, max_chars=2000)

if st.button('Predict Personality'):
    prediction = predict_personality(user_input)
    st.write(f'Predicted Personality Type: {prediction}')

    # Load the description from the text file
    with open(f"./{prediction}.txt", "r") as file:
        description = file.read()
    st.write(description)
